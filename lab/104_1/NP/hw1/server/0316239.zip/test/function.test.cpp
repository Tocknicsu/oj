#include "function.h"
#include <iostream>
using namespace std;

int main(){
    cout << exec_path() << endl;
    cout << judgecenter_dir() << endl;
    return 0;
}
