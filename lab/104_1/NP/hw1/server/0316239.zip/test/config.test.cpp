#include "config.h"
#include <iostream>
using namespace std;

int main(){
    CONFIG config;
    cout << config.mysql_user() << endl;
}
